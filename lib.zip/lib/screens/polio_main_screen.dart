import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'package:flutter_app/screens/child_detail_screen.dart';
import 'package:flutter_app/widgets/form/list_model.dart';

class PolioMain extends StatefulWidget {
  @override
  _PolioMainState createState() => _PolioMainState();
}

class _PolioMainState extends State<PolioMain> {
  final _auth = FirebaseAuth.instance;
  Stream<DocumentSnapshot> documentSnapshot;
  int _selectedIndex = 0;
  int pincode = 111111;
  List locations = ['empty'];
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Polio Notifier'),
          actions: [
            DropdownButton(
              icon: Icon(
                Icons.more_vert,
                color: Theme.of(context).primaryIconTheme.color,
              ),
              items: [
                DropdownMenuItem(
                  child: Container(
                    child: Row(
                      children: [
                        Icon(Icons.exit_to_app),
                        SizedBox(
                          width: 8,
                        ),
                        Text("Logout"),
                      ],
                    ),
                  ),
                  value: 'logout',
                ),
              ],
              onChanged: (itemIdentifier) {
                if (itemIdentifier == 'logout') {
                  _auth.signOut();
                }
              },
            ),
          ],
        ),
        bottomNavigationBar: BottomNavigationBar(items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home, color: Color.fromARGB(255, 0, 0, 0)),
            title: new Text(''),
          ),
          BottomNavigationBarItem(
              icon: Icon(Icons.alarm, color: Color.fromARGB(255, 0, 0, 0)),
              title: new Text('')),
        ]),
        body: Column(
          children: [
            Container(
                margin: EdgeInsets.only(top: 20),
                child: FlatButton(
                  onPressed: () async {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => (ChildDetail())),
                    );
                  },
                  child: Card(
                    elevation: 5,
                    color: Colors.greenAccent[400],
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 35),
                      child: Row(
                        children: [
                          SizedBox(
                            width: 20,
                          ),
                          Text(
                            'Add Detail of Child',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 25),
                          ),
                          SizedBox(
                            width: 35,
                          ),
                          Icon(Icons.navigate_next),
                        ],
                      ),
                    ),
                  ),
                )),
            Row(
              children: [
                FlatButton(
                  child: Text('Refresh Following list'),
                  onPressed: () async {
                    documentSnapshot = FirebaseFirestore.instance
                        .collection('users')
                        .doc(_auth.currentUser.uid)
                        .get()
                        .asStream();

                    print(_auth.currentUser.uid);
                    documentSnapshot.forEach((element) {
                      pincode = element.data()['pincode'];
                    });
                    print('pincode' + pincode.toString());
                    FirebaseFirestore.instance
                        .collection('camps')
                        .doc(pincode.toString())
                        .snapshots()
                        .listen((data) {
                      locations = null;
                      locations = data.data()['schoolname'];
                      print('locations');
                      print(locations);
                    });
                    setState(() {});
                  },
                ),
                SizedBox(
                  width: 75,
                ),
                FlatButton(
                  onPressed: () {},
                  child: Icon(Icons.ring_volume, color: Colors.blueAccent),
                ),
              ],
            ),
            Container(
              height: 350,
              child: ListView(
                children: [
                  ...locations.map((value) {
                    return ListModel(value);
                  })
                ],
              ),
            ),
          ],
        ));
  }
}
